import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import GuildConfig from '../../models/GuildConfig';
export default {
  data: new SlashCommandBuilder().setName('loa').setDescription('Config').addSubcommand(s=>s.setName('config').setDescription('Modify config').addStringOption(o=>o.setName('setting').setDescription('Setting').addChoices({name:'Log Channel',value:'logChannel'},{name:'Staff Role',value:'staffRole'},{name:'Admin Role',value:'adminRole'},{name:'LOA Role',value:'loaRole'},{name:'Max Duration',value:'maxLoaDuration'},{name:'Cooldown',value:'cooldownHours'})).addStringOption(o=>o.setName('value').setDescription('Value'))),
  async execute(interaction:any) {
    const config = await GuildConfig.findOne({guildId:interaction.guildId});
    if(!config) return interaction.reply({content:'Use /setup.', ephemeral:true});
    const member = await interaction.guild.members.fetch(interaction.user.id);
    if(!member.roles.cache.has(config.adminRole??'') && !member.permissions.has('Administrator')) return interaction.reply({content:'Admin only.', ephemeral:true});
    const setting = interaction.options.getString('setting');
    const value = interaction.options.getString('value');
    if(!setting) {
      const embed = new EmbedBuilder().setColor(0x5865F2).setTitle('Configuration')
        .addFields([
          {name:'Log Channel',value:config.logChannel?'<#'+config.logChannel+'>':'Not set',inline:true},
          {name:'Staff Role',value:config.staffRole?'<@&'+config.staffRole+'>':'Not set',inline:true},
          {name:'Admin Role',value:config.adminRole?'<@&'+config.adminRole+'>':'Not set',inline:true},
          {name:'Max Duration',value:config.maxLoaDuration+'d',inline:true},
          {name:'Cooldown',value:config.cooldownHours+'h',inline:true}
        ]);
      return interaction.reply({embeds:[embed], ephemeral:true});
    }
    if(!value) return interaction.reply({content:'Provide a value.', ephemeral:true});
    switch(setting) {
      case'logChannel':{const m=value.match(/<#(d+)>/)||value.match(/^(d+)$/);if(!m)return interaction.reply({content:'Invalid.',ephemeral:true});config.logChannel=m[1];break;}
      case'staffRole':{const m=value.match(/<@&(d+)>/)||value.match(/^(d+)$/);if(!m)return interaction.reply({content:'Invalid.',ephemeral:true});config.staffRole=m[1];break;}
      case'adminRole':{const m=value.match(/<@&(d+)>/)||value.match(/^(d+)$/);if(!m)return interaction.reply({content:'Invalid.',ephemeral:true});config.adminRole=m[1];break;}
      case'loaRole':{const m=value.match(/<@&(d+)>/)||value.match(/^(d+)$/);if(!m)return interaction.reply({content:'Invalid.',ephemeral:true});config.loaRole=m[1];break;}
      case'maxLoaDuration':{const n=parseInt(value);if(isNaN(n)||n<1||n>365)return interaction.reply({content:'1-365.',ephemeral:true});config.maxLoaDuration=n;break;}
      case'cooldownHours':{const n=parseInt(value);if(isNaN(n)||n<0||n>720)return interaction.reply({content:'0-720.',ephemeral:true});config.cooldownHours=n;break;}
    }
    await config.save();
    await interaction.reply({embeds:[new EmbedBuilder().setColor(0x57F287).setTitle('Updated').setDescription(setting+' = '+value)], ephemeral:true});
  }
};