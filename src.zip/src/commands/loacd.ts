import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import LOA from '../models/LOA';
import GuildConfig from '../models/GuildConfig';
export default {
  data: new SlashCommandBuilder().setName('loacd').setDescription('Check cooldown').addUserOption(o=>o.setName('user').setDescription('User')),
  async execute(interaction:any) {
    const config = await GuildConfig.findOne({guildId:interaction.guildId});
    if(!config) return interaction.reply({content:'Use /setup first.', ephemeral:true});
    const target = interaction.options.getUser('user')||interaction.user;
    if(target.id!==interaction.user.id) {
      const member = await interaction.guild.members.fetch(interaction.user.id);
      if(!member.roles.cache.has(config.staffRole??'') && !member.roles.cache.has(config.adminRole??'') && !member.permissions.has('Administrator'))
        return interaction.reply({content:'Cannot check others.', ephemeral:true});
    }
    const recent = await LOA.findOne({userId:target.id, guildId:interaction.guildId, createdAt:{$gte:new Date(Date.now()-config.cooldownHours*3600000)}}).sort({createdAt:-1});
    const embed = new EmbedBuilder().setTitle('Cooldown').addFields([{name:'User',value:'<@'+target.id+'>',inline:true},{name:'Cooldown',value:config.cooldownHours+'h',inline:true}]);
    if(recent) {
      const end = new Date(recent.createdAt.getTime()+config.cooldownHours*3600000);
      const left = end.getTime()-Date.now();
      embed.setColor(left>0?0xFEE75C:0x57F287).addFields([{name:'Status',value:left>0?'On Cooldown':'Available',inline:true}]);
      if(left>0) embed.addFields([{name:'Ready',value:'<t:'+Math.floor(end.getTime()/1000)+':R>',inline:true}]);
    } else embed.setColor(0x57F287).addFields([{name:'Status',value:'Available',inline:true}]);
    await interaction.reply({embeds:[embed], ephemeral:true});
  }
};