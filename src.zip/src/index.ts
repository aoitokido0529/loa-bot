import { Client, GatewayIntentBits, Collection } from 'discord.js';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Logger from './utils/logger';
dotenv.config();
const logger = new Logger();

class LOABot extends Client {
  public commands = new Collection<string, any>();
  public cooldowns = new Collection<string, Collection<string, number>>();

  constructor() {
    super({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });
  }

  async init() {
    try {
      if (!process.env.DISCORD_TOKEN) { logger.error('Missing DISCORD_TOKEN'); process.exit(1); }
      await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/discord-loa-bot');
      logger.success('MongoDB connected');
      await this.loadCommands();
      logger.success('Loaded '+this.commands.size+' commands');
      await this.loadEvents();
      logger.success('Events loaded');
      await this.login(process.env.DISCORD_TOKEN);
    } catch (e) { logger.error('Startup failed:', e); process.exit(1); }
  }

  private async loadCommands() {
    const mods = [
      (await import('./commands/setup')).default,
      (await import('./commands/loarequest')).default,
      (await import('./commands/loalist')).default,
      (await import('./commands/loacd')).default,
      (await import('./commands/loa/approve')).default,
      (await import('./commands/loa/deny')).default,
      (await import('./commands/loa/cancel')).default,
      (await import('./commands/loa/extend')).default,
      (await import('./commands/loa/history')).default,
      (await import('./commands/loa/config')).default,
      (await import('./commands/loawl')).default
    ];
    for (const m of mods) { if (m?.data) this.commands.set(m.data.name, m); }
  }

  private async loadEvents() {
    const readyEvent = (await import('./events/ready')).default;
    const interactionEvent = (await import('./events/interactionCreate')).default;
    if (readyEvent) this.once(readyEvent.name as string, () => readyEvent.execute(this));
    if (interactionEvent) this.on(interactionEvent.name as string, (interaction:any) => interactionEvent.execute(interaction, this));
  }
}

process.on('unhandledRejection', e => logger.error('Unhandled rejection:', e));
process.on('uncaughtException', e => { logger.error('Uncaught exception:', e); process.exit(1); });
const bot = new LOABot();
bot.init();